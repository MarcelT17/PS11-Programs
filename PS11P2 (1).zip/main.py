def dl1 (mylist):
  n = int(input("Number of items for your list"))
  for n in range(0,n,1):
    s = int(input("Enteran integer"))
    mylist.append(s)
  return mylist
def displaylist(mylist):
   for item in mylist:
    print(item)

#main
mylist = [] 
mylist = dl1(mylist)
#displaylist(mylist) # display each item in the list
print(mylist)

mylist.insert(0,99)
print(mylist)
