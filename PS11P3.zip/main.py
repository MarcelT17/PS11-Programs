def dl1 (mylist):
  n = int(input("Number of items for your list"))
  for n in range(0,n,100):
    s = int(input("Enteran integer"))
    mylist.append(s)
  return mylist
def displaylist(mylist):
   for item in mylist:
    print(item)

#main
mylist = [] 
mylist = dl1(mylist)
displaylist(mylist)
print(mylist)

mylist[0] = 100
print(mylist)
