def dl1 (mylist1):
  n = int(input("Number of items for your list"))
  for n in range(0,n,1):
    s = int(input("Enteran integer"))
    mylist1.append(s)
  return mylist1
def displaylist(mylist1):
   for item in mylist1:
    print(item)

#main
mylist1 = [] 
mylist1 = dl1(mylist1)
#displaylist(mylist) # display each item in the list
print(mylist1)

mylist1.insert(0,99)
print(mylist1)

mylist1[0] = 100
print(mylist1)

mylist2 = ["500", "600", "700", "800", "900"]
mylist1.extend(mylist2)
print(mylist1)

mylist2.remove("800")
print(mylist2)
